package com.faiqa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaCeboOkLogin1Application {

	public static void main(String[] args) {
		SpringApplication.run(FaCeboOkLogin1Application.class, args);
	}

}
