package com.faiqa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaCeboOkLogin1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
